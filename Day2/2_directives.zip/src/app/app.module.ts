import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RootComponent } from './components/root/root.component';
import { AssignTwoComponent } from './components/assign-two/assign-two.component';
import { ListComponent } from './components/list/list.component';
import { ListSwitchComponent } from './components/list-switch/list-switch.component';
import { ChangeContentDirective } from './directives/change-content.directive';
import { HighlightDirective } from './directives/highlight.directive';

@NgModule({
  declarations: [
    RootComponent,
    AssignTwoComponent,
    ListComponent,
    ListSwitchComponent,
    ChangeContentDirective,
    HighlightDirective
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  bootstrap: [RootComponent]
})
export class AppModule { }