import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'list-switch',
  templateUrl: './list-switch.component.html',
  styles: [
  ]
})
export class ListSwitchComponent implements OnInit {
  persons: any[];

  constructor() {
    this.persons = [
      {
        name: "Manish",
        pin: 411021,
        country: "India"
      },
      {
        name: "Abhijeet",
        pin: 411038,
        country: "India"
      },
      {
        name: "Ramakant",
        pin: 111111,
        country: "UK"
      },
      {
        name: "Subodh",
        pin: 222222,
        country: "UK"
      }
    ];
   }

  ngOnInit(): void {
  }

}
