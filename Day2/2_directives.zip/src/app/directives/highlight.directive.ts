// import { Directive, ElementRef, OnInit, Renderer2 } from '@angular/core';

// @Directive({
//   selector: '[highlight]'
// })
// export class HighlightDirective implements OnInit {
//   constructor(private element: ElementRef<HTMLElement>, private renderer: Renderer2) { }

//   ngOnInit(): void {
//     this.element.nativeElement.addEventListener("mouseenter", () => {
//       this.renderer.setStyle(this.element.nativeElement, "background-color", "yellow");
//     });

//     this.element.nativeElement.addEventListener("mouseleave", () => {
//       this.renderer.removeStyle(this.element.nativeElement, "background-color");
//     });
//   }
// }

// --------------------------------------------------------------------------------------------------

// import { Directive, ElementRef, HostListener, Renderer2 } from '@angular/core';

// @Directive({
//   selector: '[highlight]'
// })
// export class HighlightDirective {
//   constructor(private element: ElementRef<HTMLElement>, private renderer: Renderer2) { }

//   @HostListener('mouseenter')
//   onMouseEnter() {
//     this.renderer.setStyle(this.element.nativeElement, "background-color", "yellow");
//   }

//   @HostListener('mouseleave')
//   onMouseLeave() {
//     this.renderer.removeStyle(this.element.nativeElement, "background-color");
//   }
// }


// --------------------------------------------------------------------------------------------------

import { Directive, ElementRef, HostListener, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[highlight]'
})
export class HighlightDirective {
  // @Input() highlightColor: string;
  @Input("highlight") highlightColor: string;

  constructor(private element: ElementRef<HTMLElement>, private renderer: Renderer2) { 
    this.highlightColor = "yellow";
  }

  @HostListener('mouseenter')
  onMouseEnter() {
    this.renderer.setStyle(this.element.nativeElement, "background-color", this.highlightColor);
  }

  @HostListener('mouseleave')
  onMouseLeave() {
    this.renderer.removeStyle(this.element.nativeElement, "background-color");
  }
}