import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
  transform(value: string[], args = ""): string[] {
    return value.filter(name => name.toLowerCase().startsWith(args.toLowerCase()));
  }
}
