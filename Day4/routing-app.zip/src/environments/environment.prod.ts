export const environment = {
  production: true,
  usersUrl: 'http://www.abc.com/api/users'
};
