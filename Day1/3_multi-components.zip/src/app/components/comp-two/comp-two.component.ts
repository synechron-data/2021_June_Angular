import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-two',
  template: `
    <div class="container">
      <h1 class="text-success">
        Hello from Component Two!
      </h1>
    </div>
  `,
  styles: [
  ]
})
export class CompTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
