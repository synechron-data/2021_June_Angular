import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-one',
  template: `
    <div class="container">
      <h1 class="text-info">
        Hello from Component One!
      </h1>
    </div>
  `,
  styles: [
  ]
})
export class CompOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
