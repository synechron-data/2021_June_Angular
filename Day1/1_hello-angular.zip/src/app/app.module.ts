// ----------------------------------------- Default/Automatic Bootstrapping
// import { NgModule } from '@angular/core';
// import { BrowserModule } from '@angular/platform-browser';
// import { HelloComponent } from './components/hello/hello.component';

// @NgModule({
//   declarations: [
//     HelloComponent
//   ],
//   imports: [BrowserModule],
//   bootstrap: [HelloComponent]
// })
// export class AppModule { }

// ----------------------------------------- Manual/Custom Bootstrapping
import { ApplicationRef, DoBootstrap, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HelloComponent } from './components/hello/hello.component';
import { Hello1Component } from './components/hello1/hello1.component';

@NgModule({
  declarations: [HelloComponent, Hello1Component],
  imports: [BrowserModule],
  entryComponents: [HelloComponent, Hello1Component]
})
export class AppModule implements DoBootstrap {
  ngDoBootstrap(appRef: ApplicationRef): void {
    if (true) {
      const container = document.querySelector("#container");

      const helloTag = document.createElement('app-hello');
      helloTag.innerText = "Hello Tag Added Manually";
      // if (container !== null)
      //   container.appendChild(helloTag);

      container?.appendChild(helloTag);

      appRef.bootstrap(HelloComponent);
    }
    else {
      const container = document.querySelector("#container");

      const hello1Tag = document.createElement('app-hello1');
      hello1Tag.innerText = "Hello Tag Added Manually";
      // if (container !== null)
      //   container.appendChild(helloTag);

      container?.appendChild(hello1Tag);

      appRef.bootstrap(Hello1Component);
    }
  }
}

