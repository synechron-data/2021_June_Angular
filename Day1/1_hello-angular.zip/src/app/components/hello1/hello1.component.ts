import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hello1',
  template: `
    <p>
      hello1 works!
    </p>
  `,
  styles: [
  ]
})
export class Hello1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
