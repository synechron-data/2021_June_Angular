import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: 'root.component.html',
    styleUrls: ['./root.component.css']
})

export class RootComponent implements OnInit {
    data: string;
    constructor() {
        this.data = "From Root";
    }

    ngOnInit() {
    }

    onNewValue(val: any) {
        console.log(val);
    }
}