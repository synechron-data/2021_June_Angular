import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'greetings',
  templateUrl: './greetings.component.html',
  styles: [
  ]
})
export class GreetingsComponent implements OnInit {
  @Input() name: string;

  constructor() { 
    this.name = "";
  }

  ngOnInit(): void {
  }
}
