import { BrowserModule } from '@angular/platform-browser';
import { APP_BOOTSTRAP_LISTENER, ComponentRef, NgModule } from '@angular/core';
import { RootComponent } from './components/root/root.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GreetingsComponent } from './components/greetings/greetings.component';
import { BiInputComponent } from './components/bi-input/bi-input.component';
import { BiContentInputComponent } from './components/bi-content-input/bi-content-input.component';
import { InputRefDirective } from './directives/input-ref.directive';

@NgModule({
  declarations: [RootComponent, GreetingsComponent, BiInputComponent, BiContentInputComponent, InputRefDirective],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  providers: [
    {
      provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
        return (component: ComponentRef<any>) => {
          console.log(component);
        }
      }
    }
  ],
  bootstrap: [RootComponent]
})
export class AppModule { }