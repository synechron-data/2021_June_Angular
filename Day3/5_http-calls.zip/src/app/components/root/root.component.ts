// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Subscription } from 'rxjs';
// import { Post } from 'src/app/models/post.interface';

// @Component({
//     selector: 'app-root',
//     templateUrl: 'root.component.html',
//     styleUrls: ['./root.component.css']
// })

// export class RootComponent implements OnInit, OnDestroy {
//     url: string;
//     message: string;
//     posts?: Array<Post>;
//     get_sub?: Subscription;

//     constructor(private httpClient: HttpClient) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Loading Data, Please wait....";
//     }

//     ngOnInit() {
//         this.get_sub = this.httpClient.get<Array<Post>>(this.url).subscribe(resData => {
//             this.posts = [...resData];
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub?.unsubscribe();
//     }
// }

// --------------------------------------------------------------------------------

// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Subscription } from 'rxjs';
// import { Post } from 'src/app/models/post.interface';
// import { PostService } from 'src/app/services/post.service';

// @Component({
//     selector: 'app-root',
//     templateUrl: 'root.component.html',
//     styleUrls: ['./root.component.css'],
//     providers: [PostService]
// })

// export class RootComponent implements OnInit, OnDestroy {
//     message: string;
//     posts?: Array<Post>;
//     get_sub?: Subscription;

//     constructor(private postService: PostService) {
//         this.message = "Loading Data, Please wait....";
//     }

//     ngOnInit() {
//         this.get_sub = this.postService.getAllPosts().subscribe(resData => {
//             this.posts = [...resData];
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub?.unsubscribe();
//     }
// }

// --------------------------------------------------------------------------------

import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Post } from 'src/app/models/post.interface';
import { PostService } from 'src/app/services/post.service';

@Component({
    selector: 'app-root',
    templateUrl: 'root.component.html',
    styleUrls: ['./root.component.css'],
    providers: [PostService]
})

export class RootComponent implements OnInit, OnDestroy {
    message: string;
    posts?: Array<Post>;
    get_sub?: Subscription;
    ins_sub?: Subscription;
    del_sub?: Subscription;

    constructor(private postService: PostService) {
        this.message = "Loading Data, Please wait....";
    }

    ngOnInit() {
        this.get_sub = this.postService.getAllPosts().subscribe(resData => {
            this.posts = [...resData];
            this.message = "";
        }, (err: string) => {
            this.message = err;
        });
    }

    insertPost() {
        let newPost: Post = {
            userId: 1,
            id: 0,
            title: "Test",
            body: "Test"
        };

        this.ins_sub = this.postService.insertPost(newPost).subscribe(resData => {
            this.posts?.unshift(resData);
            this.message = "Record Inserted Successfully...";
            setTimeout(() => {
                this.message = "";
            }, 5000);
        }, (err: string) => {
            this.message = err;
        });
    }

    deletePost(id: number, e: Event) {
        e.preventDefault();

        this.del_sub = this.postService.deletePost(id).subscribe(_ => {
            if (this.posts)
                this.posts = [...this.posts.filter(p => p.id !== id)];
            this.message = "Record Deleted Successfully...";
            setTimeout(() => {
                this.message = "";
            }, 5000);
        }, (err: string) => {
            this.message = err;
        });
    }

    ngOnDestroy(): void {
        this.get_sub?.unsubscribe();
        this.ins_sub?.unsubscribe();
        this.del_sub?.unsubscribe();
    }
}