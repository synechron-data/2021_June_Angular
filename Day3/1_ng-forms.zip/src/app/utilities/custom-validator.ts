// import { AbstractControl, ValidationErrors } from "@angular/forms";

// export class CustomValidator {
//     static ageRange(control: AbstractControl): ValidationErrors | null {
//         if (control.value !== '' && (isNaN(control.value) || control.value < 20 || control.value > 60)) {
//             return { 'ageRange': true };
//         } else {
//             return null;
//         }
//     }
// }

import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";

export class CustomValidator {
    static ageRange(min: number, max: number): ValidatorFn {
        return function (control: AbstractControl): ValidationErrors | null {
            if (control.value !== '' && (isNaN(control.value) || control.value < min || control.value > max)) {
                return { 'ageRange': true };
            } else {
                return null;
            }
        }
    }
}