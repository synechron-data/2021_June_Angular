import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styles: [
  ]
})
export class TemplateDrivenFormComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }

  logForm(frm: any) {
    console.log(frm.value);
  }
}
