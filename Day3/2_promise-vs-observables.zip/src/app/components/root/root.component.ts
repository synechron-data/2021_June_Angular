import { Component, OnInit } from '@angular/core';
import { concat, EMPTY, Observable, Observer, of, Subject, Subscription } from 'rxjs';
import { delay, filter, map, reduce, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent implements OnInit {
  obSub?: Subscription;
  subject?: Subject<number>;
  observable?: Observable<number>;

  ngOnInit(): void {
    // this.getPromise();
    // this.getObservable();

    // this.getPromise().then((data) => {
    //   console.log(`Promise Output - ${data}`);
    // }).catch((err) => {
    //   console.error(`Promise Error - ${err}`);
    // });

    // this.obSub = this.getObservable().subscribe((data) => {
    //   console.log(`Observable Output - ${data}`);
    // }, (err) => {
    //   console.error(`Observable Error - ${err}`);
    // });

    // setTimeout(() => {
    //   this.obSub?.unsubscribe();
    // }, 9000);

    // ------------------------------------- Observables are single-cast
    // this.getObservable().subscribe((data) => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // }, (err) => {
    //   console.error(`Subscriber 1, Error - ${err}`);
    // });

    // this.getObservable().subscribe((data) => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // }, (err) => {
    //   console.error(`Subscriber 2, Error - ${err}`);
    // });

    // ------------------------------------- Subjects are multi-cast
    // this.subject = this.getSubject();

    // this.subject.subscribe((data) => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // });

    // this.subject.subscribe((data) => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // });

    //  ------------------------------------- Subjects as Observable
    // this.observable = this.getSubjectAsObservable();

    // this.observable.subscribe((data) => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // });

    // this.observable.subscribe((data) => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // });

    //  ------------------------------------- Observable Operators & Methods
    // let numObservable = of(10, 20, 30, 40, 53, 60, 71, 85, 99);
    // numObservable.subscribe(n => console.log(n));

    // let evenObservables = numObservable.pipe(
    //   filter(n => n % 2 === 0),
    //   map(n => n * 10),
    //   reduce((acc, n) => acc + n)
    // );

    // evenObservables.subscribe(n => console.log(n));

    // numObservable.pipe(
    //   filter(n => n % 2 === 0),
    //   map(n => n * 10),
    //   reduce((acc, n) => acc + n)
    // ).subscribe(n => console.log(n));

    // concat(
    //   of(10, 20, 30),
    //   of(40, 50, 60)
    // ).subscribe(n => console.log(n));

    concat(
      this.delayMessage('Get Ready'),
      this.delayMessage(5),
      this.delayMessage(4),
      this.delayMessage(3),
      this.delayMessage(2),
      this.delayMessage(1),
      this.delayMessage('Go Now')
    ).subscribe(message => console.log(message));
  }

  delayMessage(message:any, delayTime = 1000){
    return EMPTY.pipe(startWith(message), delay(delayTime));
  }

  getSubjectAsObservable(): Observable<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 2000);

    return s.asObservable();
  }

  getSubject(): Subject<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 2000);

    return s;
  }

  getObservable(): Observable<number> {
    return Observable.create((ob: Observer<number>) => {
      setInterval(function () {
        // console.log("Observable - Set Interval Executed");
        ob.next(Math.random());
      }, 4000);
    })
  }

  getPromise(): Promise<number> {
    return new Promise((resolve, reject) => {
      setInterval(function () {
        // console.log("Promise - Set Interval Executed");
        resolve(Math.random());
      }, 4000);
    })
  }
}
